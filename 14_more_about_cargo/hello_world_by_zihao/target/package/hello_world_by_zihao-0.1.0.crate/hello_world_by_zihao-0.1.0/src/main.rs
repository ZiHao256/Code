//! # Hello
//!
//! Hello world by zihao

fn main() {
    println!("Hello, world!");
}
